<?php 

class Users{

    private $con;
    public function __construct(){
       
        define("HOSTNAME","localhost");
        define("USERNAME","root");
        define("PASSWORD","");
        define("DBNAME","test5");

       $this->con = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
        
    }

    //add user

    public function add_user($info){
      $name = $info['name'];
      $email = $info['email'];
      $password = $info['password'];

        $sql= "INSERT INTO `users`(`id`,`name`,`email`,`password`)
        VALUES(NULL,'$name','$email','$password')";
        
     $result = mysqli_query($this->con,"$sql");
    }



    //show Users

    public function show_users(){

      $result = mysqli_query($this->con, "SELECT * FROM `users`; ");
      return $result;
    }

}







?>